package lesson1.online;

public class Lesson1 {


    //метод 1
    // public static void main(String[] args){

//                int a = 45;
//                int b = 70;
//               int c = 30;
//               int d = 2;
//               float result;
//
//               result = a * (b + (c / d));
//
//                result = myMath(a, b, c, d);
//
//                System.out.println(result);
//
//
//            }
//
//            public static float myMath(int valueA, int valueB, int valueC, int valueD) {
//                return valueA * (valueB + (valueC / valueD));
//
//
//          }
//       }


// метод 2
//        static boolean myMath (int a, int b){
//
//            int sum = a + b;
//            if (sum > 10 && sum < 20) return true;
//            else return false;
//        }
//    public static void main(String[] args){
//        System.out.println( myMath(10, 90) );
//    }
//}

    //метод 3
//    public static void main(String[] args) {

//        int a = 3, b = 3, c = 0;
//
//        c = a - b; // с = 3 - 3 = 0
//        System.out.println("с = " + c);
//        if (c >= 0) {
//            System.out.println("с не отрицательно");
//        }
//        if (c < 0) {
//
//        }
//    }
//}


//метод 4

//public static void main(String[] args) {
//
//    doSomething1();
//}
//public static void doSomething1() {
//        System.out.println("Hello, Eugene");
//    }
//



//}